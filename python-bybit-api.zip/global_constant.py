
# mainnet_url = 'https://api.bybit.com'
# api_key = '7270jBNmOvsunjeGL5'
# secret_key = 'uXvIZ3WuZFu1opxhfY8WGqap5eMJY9aDpzey'
# server_base_url = mainnet_url

testnet_url = 'https://api-testnet.bybit.com'
api_key = 'CtXGhVF2ubhX72V5aA'
secret_key = 'dgxl06MmeFpp3gayqw4gDQFvwhUeerW1hyOh'
server_base_url = testnet_url